"use strict";
exports.__esModule = true;
exports.ALLOW_DOMAIN = ["yourdomain.com","www.jwplayer.com"]; //Domain you want to play. Put [] if you want to play on all domains.
